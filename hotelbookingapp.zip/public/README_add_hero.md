Place the background image file provided as an attachment here so the site uses it as the hero background.

1. Save the attached image as: public/hero.jpg
2. Start the dev server (if not running):

   npm run dev

3. Vite serves files in `public` at the project root. The CSS in `src/new-styles.css` prefers `/hero.jpg` and falls back to an Unsplash image if the local file is missing.

Notes:
- Use JPEG or PNG. Keep the filename exactly `hero.jpg`.
- For better performance, you can resize the image to a wide desktop size (e.g., 1600–2400px wide) before saving.
