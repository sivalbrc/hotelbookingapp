/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.jsx":
/*!************************!*\
  !*** ./pages/_app.jsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_context_BookingContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../src/context/BookingContext */ \"./src/context/BookingContext.jsx\");\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_context_BookingContext__WEBPACK_IMPORTED_MODULE_2__.BookingProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\vedur\\\\Downloads\\\\Full-stack-hotel-booking-main\\\\simple-booking\\\\pages\\\\_app.jsx\",\n            lineNumber: 7,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\vedur\\\\Downloads\\\\Full-stack-hotel-booking-main\\\\simple-booking\\\\pages\\\\_app.jsx\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQThCO0FBQ2lDO0FBRWhELFNBQVNDLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQ0UsOERBQUNILHdFQUFlQTtrQkFDZCw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUc5QiIsInNvdXJjZXMiOlsid2VicGFjazovL3NpbXBsZS1ib29raW5nLy4vcGFnZXMvX2FwcC5qc3g/NGNiMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3N0eWxlcy9nbG9iYWxzLmNzcydcclxuaW1wb3J0IHsgQm9va2luZ1Byb3ZpZGVyIH0gZnJvbSAnLi4vc3JjL2NvbnRleHQvQm9va2luZ0NvbnRleHQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KXtcclxuICByZXR1cm4gKFxyXG4gICAgPEJvb2tpbmdQcm92aWRlcj5cclxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgPC9Cb29raW5nUHJvdmlkZXI+XHJcbiAgKVxyXG59XHJcbiJdLCJuYW1lcyI6WyJCb29raW5nUHJvdmlkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.jsx\n");

/***/ }),

/***/ "./src/context/BookingContext.jsx":
/*!****************************************!*\
  !*** ./src/context/BookingContext.jsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   BookingProvider: () => (/* binding */ BookingProvider),\n/* harmony export */   useBooking: () => (/* binding */ useBooking)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst BookingContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();\nfunction BookingProvider({ children }) {\n    const [bookings, setBookings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        try {\n            const raw = localStorage.getItem(\"bookings_v1\");\n            if (raw) setBookings(JSON.parse(raw));\n        } catch (e) {}\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        try {\n            localStorage.setItem(\"bookings_v1\", JSON.stringify(bookings));\n        } catch (e) {}\n    }, [\n        bookings\n    ]);\n    function addBooking(b) {\n        setBookings((prev)=>[\n                b,\n                ...prev\n            ]);\n    }\n    function cancelBooking(id) {\n        setBookings((prev)=>prev.map((b)=>b.id === id ? {\n                    ...b,\n                    status: \"Cancelled\"\n                } : b));\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(BookingContext.Provider, {\n        value: {\n            bookings,\n            addBooking,\n            cancelBooking\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\vedur\\\\Downloads\\\\Full-stack-hotel-booking-main\\\\simple-booking\\\\src\\\\context\\\\BookingContext.jsx\",\n        lineNumber: 28,\n        columnNumber: 5\n    }, this);\n}\nfunction useBooking() {\n    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(BookingContext);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29udGV4dC9Cb29raW5nQ29udGV4dC5qc3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE2RTtBQUU3RSxNQUFNSywrQkFBaUJKLG9EQUFhQTtBQUU3QixTQUFTSyxnQkFBZ0IsRUFBRUMsUUFBUSxFQUFFO0lBQzFDLE1BQU0sQ0FBQ0MsVUFBVUMsWUFBWSxHQUFHTCwrQ0FBUUEsQ0FBQyxFQUFFO0lBRTNDRCxnREFBU0EsQ0FBQztRQUNSLElBQUc7WUFDRCxNQUFNTyxNQUFNQyxhQUFhQyxPQUFPLENBQUM7WUFDakMsSUFBSUYsS0FBS0QsWUFBWUksS0FBS0MsS0FBSyxDQUFDSjtRQUNsQyxFQUFDLE9BQU1LLEdBQUUsQ0FBQztJQUNaLEdBQUUsRUFBRTtJQUVKWixnREFBU0EsQ0FBQztRQUNSLElBQUc7WUFBRVEsYUFBYUssT0FBTyxDQUFDLGVBQWVILEtBQUtJLFNBQVMsQ0FBQ1Q7UUFBVyxFQUFFLE9BQU1PLEdBQUUsQ0FBQztJQUNoRixHQUFFO1FBQUNQO0tBQVM7SUFFWixTQUFTVSxXQUFXQyxDQUFDO1FBQ25CVixZQUFZVyxDQUFBQSxPQUFRO2dCQUFDRDttQkFBTUM7YUFBSztJQUNsQztJQUVBLFNBQVNDLGNBQWNDLEVBQUU7UUFDdkJiLFlBQVlXLENBQUFBLE9BQVFBLEtBQUtHLEdBQUcsQ0FBQ0osQ0FBQUEsSUFBSUEsRUFBRUcsRUFBRSxLQUFHQSxLQUFLO29CQUFDLEdBQUdILENBQUM7b0JBQUVLLFFBQVE7Z0JBQVcsSUFBSUw7SUFDN0U7SUFFQSxxQkFDRSw4REFBQ2QsZUFBZW9CLFFBQVE7UUFBQ0MsT0FBTztZQUFFbEI7WUFBVVU7WUFBWUc7UUFBYztrQkFDbkVkOzs7Ozs7QUFHUDtBQUVPLFNBQVNvQjtJQUNkLE9BQU96QixpREFBVUEsQ0FBQ0c7QUFDcEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zaW1wbGUtYm9va2luZy8uL3NyYy9jb250ZXh0L0Jvb2tpbmdDb250ZXh0LmpzeD9lMmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBCb29raW5nQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEJvb2tpbmdQcm92aWRlcih7IGNoaWxkcmVuIH0pe1xyXG4gIGNvbnN0IFtib29raW5ncywgc2V0Qm9va2luZ3NdID0gdXNlU3RhdGUoW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKT0+e1xyXG4gICAgdHJ5e1xyXG4gICAgICBjb25zdCByYXcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYm9va2luZ3NfdjEnKVxyXG4gICAgICBpZiAocmF3KSBzZXRCb29raW5ncyhKU09OLnBhcnNlKHJhdykpXHJcbiAgICB9Y2F0Y2goZSl7fVxyXG4gIH0sW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKT0+e1xyXG4gICAgdHJ5eyBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYm9va2luZ3NfdjEnLCBKU09OLnN0cmluZ2lmeShib29raW5ncykpIH0gY2F0Y2goZSl7fVxyXG4gIH0sW2Jvb2tpbmdzXSlcclxuXHJcbiAgZnVuY3Rpb24gYWRkQm9va2luZyhiKXtcclxuICAgIHNldEJvb2tpbmdzKHByZXYgPT4gW2IsIC4uLnByZXZdKVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2FuY2VsQm9va2luZyhpZCl7XHJcbiAgICBzZXRCb29raW5ncyhwcmV2ID0+IHByZXYubWFwKGI9PiBiLmlkPT09aWQgPyB7Li4uYiwgc3RhdHVzOiAnQ2FuY2VsbGVkJ30gOiBiKSlcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Qm9va2luZ0NvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgYm9va2luZ3MsIGFkZEJvb2tpbmcsIGNhbmNlbEJvb2tpbmcgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQm9va2luZ0NvbnRleHQuUHJvdmlkZXI+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlQm9va2luZygpe1xyXG4gIHJldHVybiB1c2VDb250ZXh0KEJvb2tpbmdDb250ZXh0KVxyXG59XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJCb29raW5nQ29udGV4dCIsIkJvb2tpbmdQcm92aWRlciIsImNoaWxkcmVuIiwiYm9va2luZ3MiLCJzZXRCb29raW5ncyIsInJhdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJlIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImFkZEJvb2tpbmciLCJiIiwicHJldiIsImNhbmNlbEJvb2tpbmciLCJpZCIsIm1hcCIsInN0YXR1cyIsIlByb3ZpZGVyIiwidmFsdWUiLCJ1c2VCb29raW5nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/context/BookingContext.jsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.jsx"));
module.exports = __webpack_exports__;

})();