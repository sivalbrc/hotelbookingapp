import React, {useEffect, useState} from 'react'

export default function Bookings(){
  const [bookings, setBookings] = useState([])

  useEffect(()=>{
    const list = JSON.parse(localStorage.getItem('bookings')||'[]')
    setBookings(list.reverse())
  },[])

  function cancel(id){
    const list = JSON.parse(localStorage.getItem('bookings')||'[]')
    const idx = list.findIndex(b=>b.id===id)
    if(idx!==-1){
      list[idx].status = 'Cancelled'
      localStorage.setItem('bookings', JSON.stringify(list))
      setBookings(list.reverse())
    }
  }

  return (
    <div>
      <h2>My Bookings</h2>
      {bookings.length===0 && <p>No bookings yet.</p>}
      <div className="bookings-list">
        {bookings.map(b=> (
          <div key={b.id} className="booking-card">
            <div>
              <strong>{b.hotelName}</strong>
              <div>{b.checkIn} → {b.checkOut}</div>
              <div>ID: {b.id}</div>
            </div>
            <div>
              <div>Total: ₹{b.total}</div>
              <div>Status: {b.status}</div>
              {b.status==='Upcoming' && <button onClick={()=>cancel(b.id)}>Cancel</button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
