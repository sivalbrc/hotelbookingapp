import React, {useState} from 'react'
import { useParams, useLocation, useNavigate } from 'react-router-dom'
import { HOTELS } from '../data/hotels'
import { differenceInDays, parseISO } from 'date-fns'
import { v4 as uuidv4 } from 'uuid'

function useQuery(){ return new URLSearchParams(useLocation().search) }

export default function Booking(){
  const { id } = useParams()
  const hotel = HOTELS.find(h=>h.id===id)
  const q = useQuery()
  const type = q.get('type') || 'standard'
  const nights = Number(q.get('n')||1)
  const navigate = useNavigate()

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [requests, setRequests] = useState('')

  if(!hotel) return <div>Hotel not found</div>

  const getRoomPrice = ()=>{
    const base = hotel.price
    if(type==='deluxe') return Math.round(base*1.3)
    if(type==='suite') return Math.round(base*1.6)
    return base
  }

  const roomPrice = getRoomPrice()
  const subtotal = roomPrice * nights
  const tax = Math.round(subtotal * 0.12)
  const total = subtotal + tax

  function confirm(e){
    e?.preventDefault()
    if(!name || !email) return alert('Please enter name and email')
    const booking = {
      id: uuidv4(),
      hotelId: hotel.id,
      hotelName: hotel.name,
      type,
      nights,
      subtotal,
      tax,
      total,
      name,
      email,
      phone,
      requests,
      checkIn: q.get('ci') || '',
      checkOut: q.get('co') || '',
      createdAt: new Date().toISOString(),
      status: 'Upcoming'
    }
    const existing = JSON.parse(localStorage.getItem('bookings')||'[]')
    existing.push(booking)
    localStorage.setItem('bookings', JSON.stringify(existing))
    alert('Booking confirmed!')
    navigate('/bookings')
  }

  return (
    <div className="booking">
      <h2>Booking - {hotel.name}</h2>
      <form onSubmit={confirm} className="booking-form">
        <label>Full name<input value={name} onChange={e=>setName(e.target.value)} /></label>
        <label>Email<input value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label>Phone<input value={phone} onChange={e=>setPhone(e.target.value)} /></label>
        <label>Special requests<textarea value={requests} onChange={e=>setRequests(e.target.value)} /></label>

        <div className="summary">
          <h4>Summary</h4>
          <p>{hotel.name}</p>
          <p>Room: {type}</p>
          <p>Nights: {nights}</p>
          <p>Price/night: ₹{roomPrice}</p>
          <p>Subtotal: ₹{subtotal}</p>
          <p>GST (12%): ₹{tax}</p>
          <p className="total">Total: ₹{total}</p>
        </div>

        <div className="form-actions">
          <button type="submit">Confirm Booking (Mock Payment)</button>
        </div>
      </form>
    </div>
  )
}
