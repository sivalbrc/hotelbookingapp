import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { formatISO, isBefore, isSameDay, parseISO, addDays } from 'date-fns'

const LOCATIONS = ['Mumbai','Delhi','Bangalore','Goa','Jaipur']

export default function Search(){
  const [destination, setDestination] = useState('Mumbai')
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [guests, setGuests] = useState(1)
  const [error, setError] = useState('')
  const navigate = useNavigate()


  function validate(){
    setError('')
    if(!checkIn || !checkOut) { setError('Please select both dates'); return false }
    const now = new Date()
    const inDate = parseISO(checkIn)
    const outDate = parseISO(checkOut)
    if(isBefore(outDate, inDate) || isSameDay(outDate, inDate)) { setError('Check-out must be after check-in (minimum 1 night)'); return false }
    if(isBefore(inDate, new Date(now.toDateString()))) { setError('Dates cannot be in the past'); return false }
    return true
  }

  function submit(e){
    e?.preventDefault()
    if(!validate()) return
    const params = new URLSearchParams({
      dest: destination,
      ci: checkIn,
      co: checkOut,
      g: String(guests)
    })
  navigate('/list?'+params.toString())
  }

  // Prefill tomorrow/two nights as convenience
  React.useEffect(()=>{
    const t = new Date()
    const tom = new Date(t.getFullYear(), t.getMonth(), t.getDate()+1)
    const two = new Date(t.getFullYear(), t.getMonth(), t.getDate()+2)
    if(!checkIn) setCheckIn(tom.toISOString().slice(0,10))
    if(!checkOut) setCheckOut(two.toISOString().slice(0,10))
  },[])

  return (
    <form className="search-form" onSubmit={submit}>
      <label>Destination
        <select value={destination} onChange={e=>setDestination(e.target.value)}>
          {LOCATIONS.map(l=> <option key={l} value={l}>{l}</option>)}
        </select>
      </label>

      <label>Check-in
        <input type="date" value={checkIn} onChange={e=>setCheckIn(e.target.value)} />
      </label>

      <label>Check-out
        <input type="date" value={checkOut} onChange={e=>setCheckOut(e.target.value)} />
      </label>

      <label>Guests
        <input type="number" min={1} max={10} value={guests} onChange={e=>setGuests(Number(e.target.value))} />
      </label>

      {error && <div className="error">{error}</div>}

      <div className="form-actions">
        <button type="submit">Search</button>
      </div>
    </form>
  )
}
