import React from 'react'
import { useParams, useLocation, Link } from 'react-router-dom'
import { HOTELS } from '../data/hotels'
import { differenceInDays, parseISO } from 'date-fns'

export default function Details(){
  const { id } = useParams()
  const hotel = HOTELS.find(h=>h.id===id)
  const q = new URLSearchParams(useLocation().search)
  const ci = q.get('ci')
  const co = q.get('co')
  const nights = (ci && co) ? Math.max(1, differenceInDays(parseISO(co), parseISO(ci))) : 1

  if(!hotel) return <div>Hotel not found</div>

  const base = hotel.price
  const deluxe = Math.round(base * 1.3)
  const suite = Math.round(base * 1.6)

  return (
    <div className="details">
      <h2>{hotel.name}</h2>
      <div className="gallery">
        {hotel.images.map((img, idx) => (
          <div key={idx} className="gallery-img">
            <img src={img} alt={`${hotel.name} - Image ${idx + 1}`} 
                 loading="lazy"
                 onError={(e) => e.target.style.display = 'none'} />
          </div>
        ))}
      </div>
      <p className="hotel-meta">
        <span className="location">📍 {hotel.location}</span>
        <span className="rating">⭐ {hotel.rating.toFixed(1)}</span>
      </p>
      <h4>Amenities</h4>
      <ul>{hotel.amenities.map(a=> <li key={a}>{a}</li>)}</ul>

      <h4>Rooms</h4>
      <div className="rooms">
        {[
          { key: 'standard', title: 'Standard', price: base, img: hotel.images[0] },
          { key: 'deluxe', title: 'Deluxe', price: deluxe, img: hotel.images[1] || hotel.images[0] },
          { key: 'suite', title: 'Suite', price: suite, img: hotel.images[2] || hotel.images[0] }
        ].map(r => (
          <div className="room" key={r.key}>
            <div className="room-thumb">
              <img src={r.img} alt={`${hotel.name} - ${r.title}`} loading="lazy" onError={(e)=> e.target.style.display='none'} />
            </div>
            <div className="room-main">
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                <div>{r.title}</div>
                <div className="room-price">₹{r.price} / night</div>
              </div>
              <div className="muted">{hotel.amenities.slice(0,3).join(' • ')}</div>
              <div style={{marginTop: '0.5rem'}}>
                <Link to={`/book/${hotel.id}?type=${r.key}&n=${nights}`}>Book</Link>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  )
}
