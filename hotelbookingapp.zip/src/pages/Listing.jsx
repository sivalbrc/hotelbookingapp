import React from 'react'
import { useLocation } from 'react-router-dom'
import { HOTELS } from '../data/hotels'
import HotelCard from '../components/HotelCard'
import { differenceInDays, parseISO } from 'date-fns'

function useQuery(){
  return new URLSearchParams(useLocation().search)
}

export default function Listing(){
  const q = useQuery()
  const dest = q.get('dest') || ''
  const ci = q.get('ci') || ''
  const co = q.get('co') || ''
  const guests = Number(q.get('g')||1)
  const nights = (ci && co) ? Math.max(1, differenceInDays(parseISO(co), parseISO(ci))) : 1

  const hotels = HOTELS.filter(h=> h.location === dest)
  // compute lowest price among hotels for this destination
  const minPrice = hotels.length ? Math.min(...hotels.map(h=> h.price)) : null

  return (
    <div>
      <h2>Available hotels in {dest}</h2>
      {minPrice !== null && (
        <p style={{fontWeight:700,color:'var(--primary)'}}>Lowest price from ₹{minPrice.toLocaleString('en-IN')}</p>
      )}
      <p>{ci} → {co} • {nights} night(s) • {guests} guest(s)</p>
      <div className="hotel-list">
        {hotels.length ? hotels.map(h=> <HotelCard key={h.id} hotel={h} nights={nights}/>) : <p>No hotels found for this destination.</p>}
      </div>
    </div>
  )
}
