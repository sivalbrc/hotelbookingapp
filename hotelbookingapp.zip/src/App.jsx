import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Search from './pages/Search'
import Listing from './pages/Listing'
import Details from './pages/Details'
import Booking from './pages/Booking'
import Bookings from './pages/Bookings'

export default function App(){
  return (
    <div className="app">
      <header className="header">
        <h1><Link to="/">Simple Hotel Booking</Link></h1>
        <nav>
          <Link to="/">Search</Link>
          <Link to="/bookings">My Bookings</Link>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Search/>} />
          <Route path="/list" element={<Listing/>} />
          <Route path="/hotel/:id" element={<Details/>} />
          <Route path="/book/:id" element={<Booking/>} />
          <Route path="/bookings" element={<Bookings/>} />
        </Routes>
      </main>

      <footer className="footer">© Simple Booking - Demo</footer>
    </div>
  )
}
