export const HOTELS = [
  {
    id: 'h1',
    name: 'Sea View Resort',
    location: 'Goa',
    price: 4000,
    rating: 4.5,
    amenities: ['WiFi', 'Pool', 'Gym', 'Restaurant', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h2',
    name: 'City Center Hotel',
    location: 'Mumbai',
    price: 6000,
    rating: 4.0,
    amenities: ['WiFi', 'Restaurant', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h3',
    name: 'Garden Palace',
    location: 'Jaipur',
    price: 3500,
    rating: 3.8,
    amenities: ['WiFi', 'Pool', 'Restaurant'],
    images: [
      'https://images.unsplash.com/photo-1573052905904-34ad8c27f0cc?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1561501900-3701fa6a0864?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h4',
    name: 'Tech Park Inn',
    location: 'Bangalore',
    price: 4500,
    rating: 4.2,
    amenities: ['WiFi', 'Gym', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1606402179428-a57976d71fa4?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1594560913095-8cf34bab82ad?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1595576508898-0ad5c879a061?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h5',
    name: 'Heritage Suites',
    location: 'Delhi',
    price: 7000,
    rating: 4.8,
    amenities: ['WiFi', 'Gym', 'Restaurant', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&auto=format&fit=crop&q=80'
    ]
  }
  ,
  {
    id: 'h6',
    name: 'Bayfront Comfort',
    location: 'Goa',
    price: 3200,
    rating: 4.0,
    amenities: ['WiFi', 'Pool', 'Restaurant'],
    images: [
      'https://images.unsplash.com/photo-1501117716987-c8e1433d6f34?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1505691723518-36a3f1f4b6d8?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h7',
    name: 'Metro Stay',
    location: 'Mumbai',
    price: 4800,
    rating: 4.1,
    amenities: ['WiFi', 'Gym', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&auto=format&fit=crop&q=80'
    ]
  },
  {
    id: 'h8',
    name: 'Royal Heritage',
    location: 'Jaipur',
    price: 2900,
    rating: 3.9,
    amenities: ['WiFi', 'Restaurant', 'Parking'],
    images: [
      'https://images.unsplash.com/photo-1573052905904-34ad8c27f0cc?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800&auto=format&fit=crop&q=80'
    ]
  }
]
