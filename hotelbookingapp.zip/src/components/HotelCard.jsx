import React from 'react'
import { Link } from 'react-router-dom'

export default function HotelCard({hotel, nights}){
  const price = hotel.price
  return (
    <div className="hotel-card">
      <div className="hotel-img">
        <img src={hotel.images[0]} alt={hotel.name} 
             loading="lazy"
             onError={(e) => e.target.style.display = 'none'} />
      </div>
      <div className="hotel-body">
        <h3>{hotel.name}</h3>
        <p className="muted">
          <span className="location">📍 {hotel.location}</span>
          <span className="rating">⭐ {hotel.rating.toFixed(1)}</span>
        </p>
        <p className="amenities">
          {hotel.amenities.map(a => (
            <span key={a} className="amenity">
              {a === 'WiFi' ? '📶' : 
               a === 'Pool' ? '🏊‍♂️' : 
               a === 'Gym' ? '💪' : 
               a === 'Restaurant' ? '🍽️' : 
               a === 'Parking' ? '🅿️' : '✨'} {a}
            </span>
          ))}
        </p>
        <div className="hotel-footer">
          <div className="price">₹{price.toLocaleString('en-IN')} / night</div>
          <div className="actions">
            <Link to={`/hotel/${hotel.id}`} className="view-details">View Details</Link>
            <Link to={`/book/${hotel.id}?n=${nights||1}`} className="book-now">Book Now</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
